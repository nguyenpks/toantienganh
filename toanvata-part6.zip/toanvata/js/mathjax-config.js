/* Cấu hình MathJax dùng chung cho website và mọi bài học.
   Trong dòng: \( ... \)   Riêng dòng: \[ ... \] */
window.MathJax = {
  tex: {
    inlineMath: [['\\(', '\\)']],
    displayMath: [['\\[', '\\]']],
    packages: { '[+]': ['ams'] }
  },
  options: { skipHtmlTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code'] }
};
