# -*- coding: utf-8 -*-
"""Khung bài học chuẩn 10 mục (dùng chung cho các bài lớp 12)."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mb_lib import *

def build(lid, en_title, vi_title, topic, meta, goals, vocab, phrases, review, theory, examples, practice, mistakes, summary, checks, outpath, entry, grade=12):
    en_cat, vi_cat = topic
    reset(); set_title(lid, en_title, vi_title)
    s = H2(1, 'Lesson Introduction', 'Giới thiệu bài học')
    s += ('<div class="mbl-meta"><div><b>%s</b>%d</div><div><b>%s</b>%s</div><div><b>%s</b>%s</div><div><b>%s</b>%s</div></div>' % (
        TI('Grade', 'Khối'), grade, TI('Level', 'Mức độ'), TI(*meta['level']), TI('Time', 'Thời gian'), TI(*meta['time']), TI('Before this lesson', 'Cần biết trước'), TI(*meta['before'])))
    s += BOX('blue', ('Learning goals', 'Mục tiêu bài học'), T('By the end of this lesson you can:', 'Sau bài học này, em có thể:'), UL([T(*g) for g in goals]))
    s += H2(2, 'Mathematical Vocabulary', 'Từ vựng Toán học') + UL([VOC(*v) for v in vocab])
    s += '<div class="l23only">' + H2(3, 'Useful English Phrases', 'Cụm từ tiếng Anh thường gặp') + UL([T(*p) for p in phrases]) + '</div>'
    s += H2(4, 'Prerequisite Review', 'Ôn tập kiến thức nền') + review
    s += H2(5, 'Theory', 'Lý thuyết') + theory
    s += H2(6, 'Worked Examples', 'Ví dụ có lời giải') + examples
    s += H2(7, 'Practice', 'Bài tập luyện tập') + QUIZ(practice)
    s += H2(8, 'Common Mistakes', 'Lỗi thường gặp') + BOX('yellow', None, UL([T(*m) for m in mistakes]))
    s += H2(9, 'Lesson Summary', 'Tổng kết') + UL([T(*m) for m in summary])
    s += H2(10, 'Self-assessment', 'Tự đánh giá') + CHECKS(checks)
    toc = [(1,'Introduction','Giới thiệu',False),(2,'Vocabulary','Từ vựng',False),(3,'Phrases','Cụm từ',True),(4,'Review','Ôn tập',False),(5,'Theory','Lý thuyết',False),
           (6,'Examples','Ví dụ',False),(7,'Practice','Luyện tập',False),(8,'Mistakes','Lỗi thường gặp',False),(9,'Summary','Tổng kết',False),(10,'Self-check','Tự đánh giá',False)]
    sub = TI('Grade %d · Topic: ' % grade + en_cat, 'Lớp %d · Chủ đề: ' % grade + vi_cat)
    html = PAGE(lid, en_title, 3, sub, '', s, toc)
    out = os.path.join(ROOT, outpath); os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, 'w', encoding='utf-8').write(html)
    p = os.path.join(ROOT, 'lessons.json'); d = json.load(open(p, encoding='utf-8'))
    d = [x for x in d if x['id'] != lid]
    entry['category'] = en_cat
    entry['grade'] = grade
    same = [i for i, x in enumerate(d) if x['grade'] == grade]
    idx = (max(same) + 1) if same else len(d)
    d.insert(idx, entry); json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    import vi_catalog; vi_catalog.apply()  # tiêu đề, mô tả, chủ đề, từ khóa hiển thị bằng tiếng Việt
    print('written', outpath, len(html))

def ENTRY(lid, title, desc, level, mins, pre, path, tags, grade=12):
    return {"id": lid, "grade": grade, "category": "", "title": title, "description": desc, "level": level, "estimatedMinutes": mins, "prerequisites": pre, "path": path, "tags": tags}

def STD_SUMMARY_CHECK_EN():
    return ('I understand the English instructions in this lesson.', 'Em hiểu các yêu cầu bằng tiếng Anh trong bài này.')
