# -*- coding: utf-8 -*-
"""Danh mục hiển thị bằng tiếng Việt cho lessons.json và vocab.json.
Giữ nguyên tên trường dữ liệu; chỉ GIÁ TRỊ title, description, category, tags được viết bằng tiếng Việt.
Sau khi thêm bài mới: thêm một mục vào CATALOG rồi chạy  python vi_catalog.py  (build() cũng tự gọi apply())."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mb_lib import ROOT

CAT_VI = {
 'Sets and Intervals': 'Tập hợp và khoảng', 'Algebraic Expressions': 'Biểu thức đại số', 'Algebra': 'Đại số',
 'Functions': 'Hàm số', 'Applications of Derivatives': 'Ứng dụng của đạo hàm',
 'Monotonicity and Extrema': 'Tính đơn điệu và cực trị', 'Antiderivatives': 'Nguyên hàm'}

# id: (tiêu đề, mô tả, các từ khóa)
CATALOG = {
 'g10-sets-01': ('Tập hợp và khoảng', 'Học ký hiệu tập hợp, các phép toán trên tập hợp và cách viết khoảng, đoạn, nửa khoảng, kèm thuật ngữ tiếng Anh.', ['tập hợp', 'khoảng', 'biểu đồ Venn', 'từ vựng']),
 'g10-sets-02': ('Đếm bằng biểu đồ Venn', 'Đếm số phần tử của hai tập hợp bằng biểu đồ Venn và công thức tính số phần tử của hợp.', ['biểu đồ Venn', 'đếm', 'hợp', 'giao']),
 'g10-algebra-01': ('Làm quen với đại số', 'Đọc, viết và rút gọn biểu thức đại số, kèm cách nói bằng tiếng Anh.', ['đại số', 'biểu thức', 'hạng tử đồng dạng', 'từ vựng']),
 'g11-functions-01': ('Làm quen với hàm số', 'Đọc và viết ký hiệu hàm số bằng tiếng Anh.', ['hàm số', 'ký hiệu']),
 'g12-deriv-app-01': ('Đường tiệm cận của đồ thị', 'Tìm tiệm cận đứng, tiệm cận ngang và tiệm cận xiên của đồ thị hàm số.', ['tiệm cận', 'tiệm cận đứng', 'tiệm cận ngang', 'tiệm cận xiên', 'hàm phân thức', 'giới hạn']),
 'g12-deriv-app-02': ('Khảo sát và vẽ đồ thị hàm số', 'Khảo sát hàm số và vẽ đồ thị theo từng bước.', ['đồ thị', 'khảo sát hàm số', 'tính đối xứng', 'tiệm cận']),
 'g12-mono-01': ('Tính đơn điệu của hàm số', 'Dùng đạo hàm để tìm khoảng đồng biến, nghịch biến của hàm số.', ['đơn điệu', 'đồng biến', 'nghịch biến', 'đạo hàm']),
 'g12-mono-02': ('Cực trị của hàm số', 'Tìm điểm cực đại, cực tiểu bằng dấu của đạo hàm và đạo hàm cấp hai.', ['cực trị', 'cực đại', 'cực tiểu', 'đạo hàm']),
 'g12-mono-03': ('Giá trị lớn nhất và nhỏ nhất', 'Tìm giá trị lớn nhất, nhỏ nhất của hàm số trên một đoạn hoặc khoảng.', ['giá trị lớn nhất', 'giá trị nhỏ nhất', 'tối ưu', 'đoạn']),
 'g12-antider-01': ('Nguyên hàm', 'Học khái niệm nguyên hàm, bảng nguyên hàm cơ bản và điều kiện ban đầu.', ['nguyên hàm', 'tích phân', 'hằng số tích phân']),
 'g12-antider-02': ('Các phương pháp tìm nguyên hàm', 'Dùng phép thế tuyến tính, đổi biến số và nguyên hàm từng phần.', ['đổi biến', 'nguyên hàm từng phần', 'nguyên hàm'])}

def apply():
    p = os.path.join(ROOT, 'lessons.json'); d = json.load(open(p, encoding='utf-8'))
    for x in d:
        x['category'] = CAT_VI.get(x['category'], x['category'])
        if x['id'] in CATALOG:
            x['title'], x['description'], x['tags'] = CATALOG[x['id']][0], CATALOG[x['id']][1], list(CATALOG[x['id']][2])
    json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    p = os.path.join(ROOT, 'data', 'vocab.json'); v = json.load(open(p, encoding='utf-8'))
    for x in v: x['category'] = CAT_VI.get(x['category'], x['category'])
    json.dump(v, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

if __name__ == '__main__':
    apply(); print('đã áp dụng danh mục tiếng Việt')
