# -*- coding: utf-8 -*-
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mb_lib import *
import mb_lib

CAT = 'Monotonicity and Extrema'
ensure_vocab([
 ('v-derivative','derivative','đạo hàm',CAT,'Find the derivative of f.','\\(f\'(x)\\)'),
 ('v-increasing','increasing function','hàm số đồng biến',CAT,'The function is increasing on (0, 2).',''),
 ('v-decreasing','decreasing function','hàm số nghịch biến',CAT,'The function is decreasing on (-1, 1).',''),
 ('v-monotonicity','monotonicity','tính đơn điệu',CAT,'Study the monotonicity of the function.',''),
 ('v-critical-point','critical point','điểm tới hạn',CAT,'Find the critical points of f.',''),
 ('v-sign-table','sign table','bảng xét dấu',CAT,'Make a sign table for f\'.',''),
 ('v-variation-table','variation table','bảng biến thiên',CAT,'Complete the variation table.',''),
 ('v-extremum','extremum','cực trị',CAT,'Find the extrema of the function.',''),
 ('v-local-maximum','local maximum','cực đại',CAT,'The function has a local maximum at x = 0.',''),
 ('v-local-minimum','local minimum','cực tiểu',CAT,'The function has a local minimum at x = 2.',''),
 ('v-second-derivative','second derivative','đạo hàm cấp hai',CAT,'Use the second derivative test.','\\(f\'\'(x)\\)'),
 ('v-discriminant','discriminant','biệt thức',CAT,'The discriminant is negative.','\\(\\Delta\\)'),
 ('v-parameter','parameter','tham số',CAT,'Find the values of the parameter m.',''),
 ('v-domain','domain','tập xác định',CAT,'State the domain of the function.',''),
 ('v-maximum-value','maximum value','giá trị lớn nhất',CAT,'Find the maximum value of f on [0, 2].',''),
 ('v-minimum-value','minimum value','giá trị nhỏ nhất',CAT,'Find the minimum value of f on [0, 2].',''),
 ('v-endpoint','endpoint','đầu mút',CAT,'Evaluate f at the endpoints.',''),
 ('v-continuous','continuous function','hàm số liên tục',CAT,'A continuous function on a closed interval.',''),
])
load_vocab()

def build(lid, en_title, vi_title, topic, meta, goals, vocab, phrases, review, theory, examples, practice, mistakes, summary, checks, outpath, entry):
    reset(); set_title(lid, en_title, vi_title)
    s = H2(1, 'Lesson Introduction', 'Giới thiệu bài học')
    s += ('<div class="mbl-meta"><div><b>%s</b>12</div><div><b>%s</b>%s</div><div><b>%s</b>%s</div><div><b>%s</b>%s</div></div>' % (
        TI('Grade', 'Khối'), TI('Level', 'Mức độ'), TI(*meta['level']), TI('Time', 'Thời gian'), TI(*meta['time']), TI('Before this lesson', 'Cần biết trước'), TI(*meta['before'])))
    s += BOX('blue', ('Learning goals', 'Mục tiêu bài học'), T('By the end of this lesson you can:', 'Sau bài học này, em có thể:'), UL([T(*g) for g in goals]))
    s += H2(2, 'Mathematical Vocabulary', 'Từ vựng Toán học') + UL([VOC(*v) for v in vocab])
    s3 = H2(3, 'Useful English Phrases', 'Cụm từ tiếng Anh thường gặp') + UL([T(*p) for p in phrases])
    s += '<div class="l23only">' + s3 + '</div>'
    s += H2(4, 'Prerequisite Review', 'Ôn tập kiến thức nền') + review
    s += H2(5, 'Theory', 'Lý thuyết') + theory
    s += H2(6, 'Worked Examples', 'Ví dụ có lời giải') + examples
    s += H2(7, 'Practice', 'Bài tập luyện tập') + QUIZ(practice)
    s += H2(8, 'Common Mistakes', 'Lỗi thường gặp') + BOX('yellow', None, UL([T(*m) for m in mistakes]))
    s += H2(9, 'Lesson Summary', 'Tổng kết') + UL([T(*m) for m in summary])
    s += H2(10, 'Self-assessment', 'Tự đánh giá') + CHECKS(checks)
    toc = [(1,'Introduction','Giới thiệu',False),(2,'Vocabulary','Từ vựng',False),(3,'Phrases','Cụm từ',True),(4,'Review','Ôn tập',False),(5,'Theory','Lý thuyết',False),
           (6,'Examples','Ví dụ',False),(7,'Practice','Luyện tập',False),(8,'Mistakes','Lỗi thường gặp',False),(9,'Summary','Tổng kết',False),(10,'Self-check','Tự đánh giá',False)]
    sub = TI('Grade 12 · Topic: Monotonicity and Extrema', 'Lớp 12 · Chủ đề: Tính đơn điệu và cực trị')
    html = PAGE(lid, en_title, 3, sub, '', s, toc)
    out = os.path.join(ROOT, outpath); os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, 'w', encoding='utf-8').write(html)
    # đăng ký vào lessons.json (idempotent), đặt sau bài lớp 12 cuối cùng
    p = os.path.join(ROOT, 'lessons.json'); d = json.load(open(p, encoding='utf-8'))
    d = [x for x in d if x['id'] != lid]
    idx = max(i for i, x in enumerate(d) if x['grade'] == 12) + 1
    d.insert(idx, entry); json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print('written', outpath, len(html))

def ENTRY(lid, title, desc, level, mins, pre, path, tags):
    return {"id": lid, "grade": 12, "category": CAT, "title": title, "description": desc, "level": level, "estimatedMinutes": mins, "prerequisites": pre, "path": path, "tags": tags}

OPEN = lambda a, b: '(%s,%s)' % (a, b)

# =====================================================================
# BÀI 1: Monotonicity of Functions
# =====================================================================
review = (T('A <b>derivative</b> tells us the slope of the tangent line. Recall these rules:', '[[Đạo hàm]] cho biết hệ số góc của tiếp tuyến. Nhắc lại các quy tắc:') +
  UL([T('\\((x^n)\'=nx^{n-1}\\)', '\\((x^n)\'=nx^{n-1}\\)'), T('\\(\\left(\\dfrac{u}{v}\\right)\'=\\dfrac{u\'v-uv\'}{v^2}\\)', '\\(\\left(\\dfrac{u}{v}\\right)\'=\\dfrac{u\'v-uv\'}{v^2}\\)')]) +
  T('The sign of a quadratic \\(ax^2+bx+c\\) (with \\(a>0\\)) is positive outside its roots and negative between them.', 'Dấu của tam thức bậc hai \\(ax^2+bx+c\\) (với \\(a>0\\)): dương ngoài hai nghiệm, âm giữa hai nghiệm.'))
theory = ('<h3>5.1 %s</h3>' % TI('Increasing and decreasing functions', 'Hàm số đồng biến, nghịch biến') +
  BOX('mint', ('Definition', 'Định nghĩa'),
    T('Let \\(K\\) be an interval. A function \\(f\\) is an <b>increasing function</b> on \\(K\\) if \\(x_1<x_2\\) implies \\(f(x_1)<f(x_2)\\). It is a <b>decreasing function</b> on \\(K\\) if \\(x_1<x_2\\) implies \\(f(x_1)>f(x_2)\\), for all \\(x_1,x_2\\in K\\).',
      'Cho \\(K\\) là một khoảng. Hàm số \\(f\\) là [[hàm số đồng biến]] trên \\(K\\) nếu \\(x_1<x_2\\) thì \\(f(x_1)<f(x_2)\\); là [[hàm số nghịch biến]] trên \\(K\\) nếu \\(x_1<x_2\\) thì \\(f(x_1)>f(x_2)\\), với mọi \\(x_1,x_2\\in K\\).')) +
  '<h3>5.2 %s</h3>' % TI('The derivative test for monotonicity', 'Dùng đạo hàm xét tính đơn điệu') +
  BOX('mint', ('Theorem', 'Định lí'),
    T('Let \\(f\\) have a derivative on an interval \\(K\\).', 'Cho hàm số \\(f\\) có [[đạo hàm]] trên khoảng \\(K\\).'),
    UL([T('If \\(f\'(x)>0\\) for all \\(x\\in K\\), then \\(f\\) is increasing on \\(K\\).', 'Nếu \\(f\'(x)>0\\) với mọi \\(x\\in K\\) thì \\(f\\) đồng biến trên \\(K\\).'),
        T('If \\(f\'(x)<0\\) for all \\(x\\in K\\), then \\(f\\) is decreasing on \\(K\\).', 'Nếu \\(f\'(x)<0\\) với mọi \\(x\\in K\\) thì \\(f\\) nghịch biến trên \\(K\\).'),
        T('The statements stay true if \\(f\'(x)=0\\) at only finitely many points of \\(K\\).', 'Các kết luận vẫn đúng nếu \\(f\'(x)=0\\) chỉ tại hữu hạn điểm của \\(K\\).')])) +
  '<h3>5.3 %s</h3>' % TI('Method', 'Các bước xét tính đơn điệu') +
  OL([T('Find the domain.', 'Tìm [[tập xác định]].'), T('Compute \\(f\'(x)\\) and find where \\(f\'(x)=0\\) or \\(f\'(x)\\) does not exist.', 'Tính \\(f\'(x)\\); tìm các điểm \\(f\'(x)=0\\) hoặc \\(f\'(x)\\) không xác định.'),
      T('Make a sign table of \\(f\'\\) (a variation table).', 'Lập [[bảng xét dấu]] của \\(f\'\\) (hoặc [[bảng biến thiên]]).'), T('Read the intervals where \\(f\\) increases and decreases.', 'Đọc các khoảng đồng biến, nghịch biến.')]))

ex = EXAMPLE(1, ('Basic', 'Cơ bản'), ('A cubic function', 'Hàm số bậc ba'),
  T('Find the intervals on which \\(f(x)=x^3-3x^2+1\\) is increasing or decreasing.', 'Tìm các khoảng đồng biến, nghịch biến của hàm số \\(f(x)=x^3-3x^2+1\\).'),
  ('The domain is \\(\\mathbb{R}\\). We need the sign of \\(f\'\\).', 'Tập xác định là \\(\\mathbb{R}\\). Cần xét dấu của \\(f\'\\).'),
  [T('\\(f\'(x)=3x^2-6x=3x(x-2)\\), and \\(f\'(x)=0\\) at \\(x=0\\) and \\(x=2\\).', '\\(f\'(x)=3x^2-6x=3x(x-2)\\) và \\(f\'(x)=0\\) tại \\(x=0\\), \\(x=2\\).'),
   T('Sign of \\(f\'\\): positive for \\(x<0\\), negative for \\(0<x<2\\), positive for \\(x>2\\).', 'Dấu của \\(f\'\\): dương khi \\(x<0\\), âm khi \\(0<x<2\\), dương khi \\(x>2\\).'),
   T('So \\(f\\) is increasing on \\((-\\infty,0)\\) and \\((2,+\\infty)\\), and decreasing on \\((0,2)\\).', 'Vậy \\(f\\) đồng biến trên \\((-\\infty,0)\\) và \\((2,+\\infty)\\), nghịch biến trên \\((0,2)\\).')],
  'increasing on \\((-\\infty,0)\\), \\((2,+\\infty)\\); decreasing on \\((0,2)\\)')
ex += EXAMPLE(2, ('Intermediate', 'Trung bình'), ('A rational function', 'Hàm phân thức'),
  T('Study the monotonicity of \\(f(x)=\\dfrac{2x+1}{x-1}\\).', 'Xét tính đơn điệu của hàm số \\(f(x)=\\dfrac{2x+1}{x-1}\\).'),
  ('The domain is \\(\\mathbb{R}\\setminus\\{1\\}\\), which is not one interval.', 'Tập xác định là \\(\\mathbb{R}\\setminus\\{1\\}\\), không phải một khoảng duy nhất.'),
  [T('\\(f\'(x)=\\dfrac{2(x-1)-(2x+1)}{(x-1)^2}=\\dfrac{-3}{(x-1)^2}\\).', '\\(f\'(x)=\\dfrac{2(x-1)-(2x+1)}{(x-1)^2}=\\dfrac{-3}{(x-1)^2}\\).'),
   T('\\(f\'(x)<0\\) for every \\(x\\ne1\\).', '\\(f\'(x)<0\\) với mọi \\(x\\ne1\\).'),
   T('So \\(f\\) is decreasing on \\((-\\infty,1)\\) and on \\((1,+\\infty)\\). We must not say it is decreasing on the union.', 'Vậy \\(f\\) nghịch biến trên \\((-\\infty,1)\\) và trên \\((1,+\\infty)\\). Không được nói nghịch biến trên hợp của hai khoảng.')],
  'decreasing on \\((-\\infty,1)\\) and on \\((1,+\\infty)\\)')
ex += EXAMPLE(3, ('Intermediate', 'Trung bình'), ('A sum with a fraction', 'Tổng có phân thức'),
  T('Study the monotonicity of \\(f(x)=x+\\dfrac{4}{x}\\).', 'Xét tính đơn điệu của hàm số \\(f(x)=x+\\dfrac{4}{x}\\).'),
  ('The domain is \\(x\\ne0\\). Write \\(f\'\\) as one fraction.', 'Tập xác định \\(x\\ne0\\). Viết \\(f\'\\) thành một phân thức.'),
  [T('\\(f\'(x)=1-\\dfrac{4}{x^2}=\\dfrac{x^2-4}{x^2}\\). It is zero at \\(x=\\pm2\\).', '\\(f\'(x)=1-\\dfrac{4}{x^2}=\\dfrac{x^2-4}{x^2}\\). Nó bằng 0 tại \\(x=\\pm2\\).'),
   T('\\(f\'>0\\) for \\(x<-2\\) and \\(x>2\\); \\(f\'<0\\) for \\(-2<x<0\\) and \\(0<x<2\\).', '\\(f\'>0\\) khi \\(x<-2\\) và \\(x>2\\); \\(f\'<0\\) khi \\(-2<x<0\\) và \\(0<x<2\\).'),
   T('So \\(f\\) is increasing on \\((-\\infty,-2)\\) and \\((2,+\\infty)\\); decreasing on \\((-2,0)\\) and \\((0,2)\\).', 'Vậy \\(f\\) đồng biến trên \\((-\\infty,-2)\\) và \\((2,+\\infty)\\); nghịch biến trên \\((-2,0)\\) và \\((0,2)\\).')],
  'increasing on \\((-\\infty,-2)\\), \\((2,+\\infty)\\); decreasing on \\((-2,0)\\), \\((0,2)\\)')
ex += EXAMPLE(4, ('Advanced', 'Nâng cao'), ('A parameter', 'Bài toán tham số'),
  T('Find all values of the <b>parameter</b> \\(m\\) such that \\(f(x)=x^3+3x^2+mx+1\\) is increasing on \\(\\mathbb{R}\\).', 'Tìm tất cả các giá trị của [[tham số]] \\(m\\) để hàm số \\(f(x)=x^3+3x^2+mx+1\\) đồng biến trên \\(\\mathbb{R}\\).'),
  ('We need \\(f\'(x)\\ge0\\) for all \\(x\\). A quadratic with \\(a>0\\) is never negative when its <b>discriminant</b> is at most 0.', 'Cần \\(f\'(x)\\ge0\\) với mọi \\(x\\). Tam thức có \\(a>0\\) không âm với mọi \\(x\\) khi [[biệt thức]] không dương.'),
  [T('\\(f\'(x)=3x^2+6x+m\\), with \\(a=3>0\\).', '\\(f\'(x)=3x^2+6x+m\\), có \\(a=3>0\\).'),
   T('\\(\\Delta\'=9-3m\\le0\\) gives \\(m\\ge3\\).', '\\(\\Delta\'=9-3m\\le0\\) cho \\(m\\ge3\\).'),
   T('For \\(m=3\\), \\(f\'(x)=3(x+1)^2\\) is zero only at \\(x=-1\\), so \\(f\\) is still increasing.', 'Với \\(m=3\\), \\(f\'(x)=3(x+1)^2\\) chỉ bằng 0 tại \\(x=-1\\) nên \\(f\\) vẫn đồng biến.')],
  '\\(m\\ge3\\)')
pr = [
 ('A. Multiple Choice', 'A. Trắc nghiệm nhiều lựa chọn'), [
  MCQ(1, ('On which interval is \\(f(x)=-x^2+4x\\) increasing?', 'Hàm số \\(f(x)=-x^2+4x\\) đồng biến trên khoảng nào?'), ['(-\\infty,2)', '(2,+\\infty)', '(-\\infty,4)', '(0,4)'], 'a',
      ('Answer: a. \\(f\'(x)=-2x+4>0\\) when \\(x<2\\).', 'Đáp án a. \\(f\'(x)=-2x+4>0\\) khi \\(x<2\\).')),
  MCQ(2, ('On which interval is \\(f(x)=x^3-3x\\) decreasing?', 'Hàm số \\(f(x)=x^3-3x\\) nghịch biến trên khoảng nào?'), ['(-\\infty,-1)', '(-1,1)', '(1,+\\infty)', '\\mathbb{R}'], 'b',
      ('Answer: b. \\(f\'(x)=3x^2-3<0\\) exactly when \\(-1<x<1\\).', 'Đáp án b. \\(f\'(x)=3x^2-3<0\\) đúng khi \\(-1<x<1\\).')),
  MCQ(3, ('Let \\(f(x)=\\dfrac{x-2}{x+1}\\). On which interval is \\(f\\) increasing?', 'Cho \\(f(x)=\\dfrac{x-2}{x+1}\\). Hàm số đồng biến trên khoảng nào?'), ['(-2,0)', '(-1,2)', '(-\\infty,0)', '\\mathbb{R}'], 'b',
      ('Answer: b. \\(f\'(x)=\\dfrac{3}{(x+1)^2}>0\\) for \\(x\\ne-1\\), but an interval must not contain \\(-1\\). Only \\((-1,2)\\) qualifies.', 'Đáp án b. \\(f\'(x)=\\dfrac{3}{(x+1)^2}>0\\) với \\(x\\ne-1\\), nhưng khoảng không được chứa \\(-1\\). Chỉ có \\((-1,2)\\) thỏa mãn.')),
  MCQ(4, ('Let \\(f\'(x)=(x-1)(x+2)^2\\). On which interval is \\(f\\) increasing?', 'Cho \\(f\'(x)=(x-1)(x+2)^2\\). Hàm số đồng biến trên khoảng nào?'), ['(-\\infty,1)', '(1,+\\infty)', '(-2,1)', '(-\\infty,-2)'], 'b',
      ('Answer: b. \\((x+2)^2\\ge0\\), so \\(f\'>0\\) exactly when \\(x>1\\).', 'Đáp án b. \\((x+2)^2\\ge0\\) nên \\(f\'>0\\) đúng khi \\(x>1\\).'))]
]
pr = [pr] if False else [(pr[0], pr[1]), (('B. True or False', 'B. Đúng hoặc sai'), [
  TF(5, ('True or false: if \\(f\'(x)>0\\) on \\((a,b)\\), then \\(f\\) is increasing on \\((a,b)\\).', 'Đúng hay sai: nếu \\(f\'(x)>0\\) trên \\((a,b)\\) thì \\(f\\) đồng biến trên \\((a,b)\\).'), 'true',
     ('True. This is the derivative test.', 'Đúng. Đây là định lí về dấu của đạo hàm.')),
  TF(6, ('True or false: \\(f(x)=\\dfrac1x\\) is decreasing on its whole domain \\(\\mathbb{R}\\setminus\\{0\\}\\).', 'Đúng hay sai: \\(f(x)=\\dfrac1x\\) nghịch biến trên toàn bộ tập xác định \\(\\mathbb{R}\\setminus\\{0\\}\\).'), 'false',
     ('False. It is decreasing on \\((-\\infty,0)\\) and on \\((0,+\\infty)\\) separately. But \\(-1<1\\) while \\(f(-1)=-1<f(1)=1\\).', 'Sai. Hàm số nghịch biến trên từng khoảng \\((-\\infty,0)\\) và \\((0,+\\infty)\\). Nhưng \\(-1<1\\) mà \\(f(-1)=-1<f(1)=1\\).'))]),
 (('C. Short Answer', 'C. Trả lời ngắn'), [
  SHORT(7, ('Write the interval on which \\(f(x)=x^2-6x+5\\) is decreasing.', 'Viết khoảng mà hàm số \\(f(x)=x^2-6x+5\\) nghịch biến.'), '(-inf,3)|(-inf,3]', 'interval',
        ('Format: (-inf,3). You may type inf for infinity.', 'Định dạng: (-inf,3). Có thể gõ inf cho vô cực.'),
        ('Answer: \\((-\\infty,3)\\). \\(f\'(x)=2x-6<0\\) when \\(x<3\\).', 'Đáp án: \\((-\\infty,3)\\). \\(f\'(x)=2x-6<0\\) khi \\(x<3\\).')),
  SHORT(8, ('How many solutions does \\(f\'(x)=0\\) have for \\(f(x)=x^4-2x^2\\)?', 'Với \\(f(x)=x^4-2x^2\\), phương trình \\(f\'(x)=0\\) có bao nhiêu nghiệm?'), '3', 'number',
        ('Enter a whole number.', 'Nhập một số nguyên.'),
        ('Answer: 3. \\(f\'(x)=4x^3-4x=4x(x-1)(x+1)\\).', 'Đáp án: 3. \\(f\'(x)=4x^3-4x=4x(x-1)(x+1)\\).')),
  SHORT(9, ('Find the smallest integer \\(m\\) such that \\(f(x)=x^3+3x^2+mx\\) is increasing on \\(\\mathbb{R}\\).', 'Tìm số nguyên \\(m\\) nhỏ nhất để \\(f(x)=x^3+3x^2+mx\\) đồng biến trên \\(\\mathbb{R}\\).'), '3', 'number',
        ('Enter a whole number.', 'Nhập một số nguyên.'),
        ('Answer: 3. We need \\(9-3m\\le0\\), so \\(m\\ge3\\).', 'Đáp án: 3. Cần \\(9-3m\\le0\\) nên \\(m\\ge3\\).')),
  SHORT(10, ('Find the smallest integer \\(m\\) such that \\(f(x)=\\dfrac{mx+1}{x-1}\\) is decreasing on each interval of its domain.', 'Tìm số nguyên \\(m\\) nhỏ nhất để \\(f(x)=\\dfrac{mx+1}{x-1}\\) nghịch biến trên từng khoảng xác định.'), '0', 'number',
        ('Enter a whole number.', 'Nhập một số nguyên.'),
        ('Answer: 0. \\(f\'(x)=\\dfrac{-m-1}{(x-1)^2}<0\\) exactly when \\(m>-1\\), so the smallest integer is 0.', 'Đáp án: 0. \\(f\'(x)=\\dfrac{-m-1}{(x-1)^2}<0\\) đúng khi \\(m>-1\\), nên số nguyên nhỏ nhất là 0.'))])]
build('g12-mono-01', 'Monotonicity of Functions', 'Tính đơn điệu của hàm số', CAT,
  {'level': ('Intermediate', 'Trung bình'), 'time': ('about 45 minutes', 'khoảng 45 phút'), 'before': ('derivative rules, sign of a quadratic, intervals', 'quy tắc đạo hàm, dấu tam thức bậc hai, khoảng')},
  [('use the derivative to find where a function increases or decreases;', 'dùng [[đạo hàm]] để tìm các khoảng [[hàm số đồng biến]], [[hàm số nghịch biến]];'),
   ('write a correct sign table and conclusion;', 'lập [[bảng xét dấu]] và kết luận đúng;'),
   ('solve a simple <b>parameter</b> problem;', 'giải bài toán [[tham số]] đơn giản;'),
   ('state the answer in English.', 'phát biểu kết quả bằng tiếng Anh.')],
  [('<b>increasing function</b> – a function whose values go up as \\(x\\) goes up.', '[[Hàm số đồng biến]] – giá trị tăng khi \\(x\\) tăng.'),
   ('<b>decreasing function</b> – a function whose values go down as \\(x\\) goes up.', '[[Hàm số nghịch biến]] – giá trị giảm khi \\(x\\) tăng.'),
   ('<b>monotonicity</b> – whether a function increases or decreases.', '[[Tính đơn điệu]] – việc hàm số tăng hay giảm.'),
   ('<b>derivative</b> – the rate of change \\(f\'(x)\\).', '[[Đạo hàm]] – tốc độ thay đổi \\(f\'(x)\\).'),
   ('<b>sign table</b> – a table showing where \\(f\'\\) is positive or negative.', '[[Bảng xét dấu]] – bảng cho biết \\(f\'\\) dương hay âm ở đâu.'),
   ('<b>parameter</b> – a letter such as \\(m\\) that stands for a fixed unknown number.', '[[Tham số]] – chữ như \\(m\\) đại diện cho một số chưa biết cố định.'),
   ('<b>discriminant</b> – the number \\(\\Delta=b^2-4ac\\).', '[[Biệt thức]] – số \\(\\Delta=b^2-4ac\\).'),
   ('<b>domain</b> – all values of \\(x\\) for which \\(f(x)\\) is defined.', '[[Tập xác định]] – mọi giá trị \\(x\\) để \\(f(x)\\) có nghĩa.')],
  [('Find the intervals on which the function is increasing.', 'Tìm các khoảng mà hàm số đồng biến.'), ('Make a sign table for the derivative.', 'Lập bảng xét dấu của đạo hàm.'),
   ('The function is decreasing on the interval \\((0,2)\\).', 'Hàm số nghịch biến trên khoảng \\((0,2)\\).'), ('Find all values of \\(m\\) such that \\(f\\) is increasing on \\(\\mathbb{R}\\).', 'Tìm tất cả giá trị của \\(m\\) để \\(f\\) đồng biến trên \\(\\mathbb{R}\\).')],
  review, theory, ex, pr,
  [('<b>Using the union of intervals.</b> For \\(\\dfrac{2x+1}{x-1}\\) write “decreasing on each interval”, not on \\((-\\infty,1)\\cup(1,+\\infty)\\).', '<b>Dùng hợp các khoảng.</b> Với \\(\\dfrac{2x+1}{x-1}\\) phải viết “nghịch biến trên từng khoảng”, không viết trên \\((-\\infty,1)\\cup(1,+\\infty)\\).'),
   ('<b>Forgetting the domain.</b> Points where \\(f\\) is not defined split the intervals.', '<b>Quên tập xác định.</b> Các điểm hàm số không xác định chia nhỏ các khoảng.'),
   ('<b>Wrong inequality for \\(m\\).</b> “Increasing on \\(\\mathbb{R}\\)” means \\(f\'\\ge0\\) (with isolated zeros allowed), so check the case \\(\\Delta=0\\).', '<b>Sai dấu bất đẳng thức với \\(m\\).</b> “Đồng biến trên \\(\\mathbb{R}\\)” nghĩa là \\(f\'\\ge0\\) (cho phép bằng 0 tại điểm rời rạc), nên phải kiểm tra trường hợp \\(\\Delta=0\\).')],
  [('If \\(f\'>0\\) on \\(K\\), \\(f\\) is increasing on \\(K\\); if \\(f\'<0\\), it is decreasing.', 'Nếu \\(f\'>0\\) trên \\(K\\) thì \\(f\\) đồng biến; nếu \\(f\'<0\\) thì nghịch biến.'),
   ('Steps: domain, \\(f\'\\), roots of \\(f\'\\), sign table, conclusion.', 'Các bước: tập xác định, \\(f\'\\), nghiệm của \\(f\'\\), bảng xét dấu, kết luận.'),
   ('For parameter problems on \\(\\mathbb{R}\\), use the discriminant of \\(f\'\\).', 'Với bài toán tham số trên \\(\\mathbb{R}\\), dùng biệt thức của \\(f\'\\).')],
  [('I can find the intervals where a function increases or decreases.', 'Em tìm được các khoảng đồng biến, nghịch biến của hàm số.'), ('I can make a correct sign table.', 'Em lập đúng bảng xét dấu.'),
   ('I can solve a simple parameter problem.', 'Em giải được bài toán tham số đơn giản.'), ('I understand the English instructions in this lesson.', 'Em hiểu các yêu cầu bằng tiếng Anh trong bài này.')],
  'lessons/grade12/monotonicity-extrema/monotonicity-of-functions.html',
  ENTRY('g12-mono-01', 'Monotonicity of Functions', 'Use the derivative to find where a function increases or decreases.', 'Intermediate', 45, [], 'lessons/grade12/monotonicity-extrema/monotonicity-of-functions.html', ['monotonicity', 'increasing', 'decreasing', 'derivative']))

# =====================================================================
# BÀI 2: Local Extrema
# =====================================================================
review2 = (T('From the last lesson: the sign of \\(f\'\\) tells us where \\(f\\) increases or decreases. A <b>critical point</b> is a point where \\(f\'(x)=0\\) or \\(f\'(x)\\) does not exist.', 'Từ bài trước: dấu của \\(f\'\\) cho biết \\(f\\) đồng biến hay nghịch biến. [[Điểm tới hạn]] là điểm mà \\(f\'(x)=0\\) hoặc \\(f\'(x)\\) không xác định.') +
  T('The <b>second derivative</b> \\(f\'\'\\) is the derivative of \\(f\'\\). For example, if \\(f(x)=x^3-3x^2\\), then \\(f\'(x)=3x^2-6x\\) and \\(f\'\'(x)=6x-6\\).', '[[Đạo hàm cấp hai]] \\(f\'\'\\) là đạo hàm của \\(f\'\\). Ví dụ, nếu \\(f(x)=x^3-3x^2\\) thì \\(f\'(x)=3x^2-6x\\) và \\(f\'\'(x)=6x-6\\).'))
theory2 = ('<h3>5.1 %s</h3>' % TI('Local maximum and local minimum', 'Cực đại và cực tiểu') +
  BOX('mint', ('Definition', 'Định nghĩa'),
    T('The point \\(x_0\\) is a <b>local maximum</b> of \\(f\\) if there is an interval \\((a,b)\\) containing \\(x_0\\) such that \\(f(x)<f(x_0)\\) for all \\(x\\in(a,b)\\setminus\\{x_0\\}\\). For a <b>local minimum</b> the inequality is \\(f(x)>f(x_0)\\). Both are called <b>extrema</b>.',
      'Điểm \\(x_0\\) là điểm [[cực đại]] của \\(f\\) nếu có khoảng \\((a,b)\\) chứa \\(x_0\\) sao cho \\(f(x)<f(x_0)\\) với mọi \\(x\\in(a,b)\\setminus\\{x_0\\}\\). Với điểm [[cực tiểu]] thì \\(f(x)>f(x_0)\\). Cả hai gọi chung là [[cực trị]].')) +
  '<h3>5.2 %s</h3>' % TI('First derivative test', 'Điều kiện đủ thứ nhất') +
  BOX('mint', ('Theorem', 'Định lí'), T('Let \\(f\\) be continuous at \\(x_0\\) and have a derivative near \\(x_0\\) (except possibly at \\(x_0\\)).', 'Cho \\(f\\) liên tục tại \\(x_0\\) và có đạo hàm ở lân cận \\(x_0\\) (có thể trừ \\(x_0\\)).'),
    UL([T('If \\(f\'\\) changes from positive to negative at \\(x_0\\), then \\(x_0\\) is a local maximum.', 'Nếu \\(f\'\\) đổi dấu từ dương sang âm tại \\(x_0\\) thì \\(x_0\\) là điểm cực đại.'),
        T('If \\(f\'\\) changes from negative to positive at \\(x_0\\), then \\(x_0\\) is a local minimum.', 'Nếu \\(f\'\\) đổi dấu từ âm sang dương tại \\(x_0\\) thì \\(x_0\\) là điểm cực tiểu.'),
        T('If \\(f\'\\) does not change sign, there is no extremum at \\(x_0\\).', 'Nếu \\(f\'\\) không đổi dấu thì \\(x_0\\) không là điểm cực trị.')])) +
  '<h3>5.3 %s</h3>' % TI('Second derivative test', 'Điều kiện đủ thứ hai') +
  BOX('mint', ('Theorem', 'Định lí'), T('Suppose \\(f\'(x_0)=0\\) and \\(f\'\'(x_0)\\) exists.', 'Giả sử \\(f\'(x_0)=0\\) và tồn tại \\(f\'\'(x_0)\\).'),
    UL([T('If \\(f\'\'(x_0)<0\\), then \\(x_0\\) is a local maximum.', 'Nếu \\(f\'\'(x_0)<0\\) thì \\(x_0\\) là điểm cực đại.'), T('If \\(f\'\'(x_0)>0\\), then \\(x_0\\) is a local minimum.', 'Nếu \\(f\'\'(x_0)>0\\) thì \\(x_0\\) là điểm cực tiểu.'),
        T('If \\(f\'\'(x_0)=0\\), the test fails; use the first derivative test.', 'Nếu \\(f\'\'(x_0)=0\\) thì không kết luận được; dùng điều kiện đủ thứ nhất.')])))
ex2 = EXAMPLE(1, ('Basic', 'Cơ bản'), ('Sign change of the derivative', 'Đổi dấu của đạo hàm'),
  T('Find the extrema of \\(f(x)=x^3-3x^2+1\\).', 'Tìm cực trị của hàm số \\(f(x)=x^3-3x^2+1\\).'),
  ('Find the roots of \\(f\'\\), then check the sign change.', 'Tìm nghiệm của \\(f\'\\), rồi xét đổi dấu.'),
  [T('\\(f\'(x)=3x(x-2)\\), zero at \\(x=0\\) and \\(x=2\\).', '\\(f\'(x)=3x(x-2)\\), bằng 0 tại \\(x=0\\) và \\(x=2\\).'),
   T('\\(f\'\\) changes from \\(+\\) to \\(-\\) at \\(x=0\\): local maximum, \\(f(0)=1\\).', '\\(f\'\\) đổi dấu từ \\(+\\) sang \\(-\\) tại \\(x=0\\): cực đại, \\(f(0)=1\\).'),
   T('\\(f\'\\) changes from \\(-\\) to \\(+\\) at \\(x=2\\): local minimum, \\(f(2)=8-12+1=-3\\).', '\\(f\'\\) đổi dấu từ \\(-\\) sang \\(+\\) tại \\(x=2\\): cực tiểu, \\(f(2)=8-12+1=-3\\).')],
  'local maximum \\(f(0)=1\\); local minimum \\(f(2)=-3\\)')
ex2 += EXAMPLE(2, ('Intermediate', 'Trung bình'), ('The second derivative test', 'Dùng đạo hàm cấp hai'),
  T('Find the extrema of \\(f(x)=x^4-2x^2+3\\).', 'Tìm cực trị của hàm số \\(f(x)=x^4-2x^2+3\\).'),
  ('Find \\(f\'\\) and \\(f\'\'\\), then test each critical point.', 'Tính \\(f\'\\) và \\(f\'\'\\), rồi xét từng điểm tới hạn.'),
  [T('\\(f\'(x)=4x(x^2-1)\\), zero at \\(x=-1,\\ 0,\\ 1\\). Also \\(f\'\'(x)=12x^2-4\\).', '\\(f\'(x)=4x(x^2-1)\\), bằng 0 tại \\(x=-1,\\ 0,\\ 1\\). Và \\(f\'\'(x)=12x^2-4\\).'),
   T('\\(f\'\'(0)=-4<0\\): local maximum, \\(f(0)=3\\).', '\\(f\'\'(0)=-4<0\\): cực đại, \\(f(0)=3\\).'),
   T('\\(f\'\'(\\pm1)=8>0\\): local minima, \\(f(\\pm1)=2\\).', '\\(f\'\'(\\pm1)=8>0\\): cực tiểu, \\(f(\\pm1)=2\\).')],
  'local maximum \\(f(0)=3\\); local minima \\(f(\\pm1)=2\\)')
ex2 += EXAMPLE(3, ('Intermediate', 'Trung bình'), ('Zero derivative, no extremum', 'Đạo hàm bằng 0 nhưng không có cực trị'),
  T('Does \\(f(x)=x^3\\) have an extremum at \\(x=0\\)?', 'Hàm số \\(f(x)=x^3\\) có cực trị tại \\(x=0\\) không?'),
  ('Check the sign of \\(f\'\\) on both sides of 0.', 'Xét dấu của \\(f\'\\) ở hai phía của 0.'),
  [T('\\(f\'(x)=3x^2\\), so \\(f\'(0)=0\\).', '\\(f\'(x)=3x^2\\) nên \\(f\'(0)=0\\).'),
   T('But \\(f\'(x)>0\\) for \\(x<0\\) and for \\(x>0\\). It does not change sign.', 'Nhưng \\(f\'(x)>0\\) khi \\(x<0\\) và khi \\(x>0\\). Nó không đổi dấu.'),
   T('So there is no extremum. \\(f\'(x_0)=0\\) is necessary, not sufficient.', 'Vậy không có cực trị. Điều kiện \\(f\'(x_0)=0\\) là cần, chưa đủ.')],
  'No extremum at \\(x=0\\)')
ex2 += EXAMPLE(4, ('Advanced', 'Nâng cao'), ('A parameter', 'Bài toán tham số'),
  T('Find all values of \\(m\\) such that \\(f(x)=x^3-3x^2+mx\\) has two extreme points.', 'Tìm tất cả giá trị của \\(m\\) để hàm số \\(f(x)=x^3-3x^2+mx\\) có hai điểm cực trị.'),
  ('Two extreme points need \\(f\'\\) to have two different roots and to change sign at them.', 'Có hai điểm cực trị khi \\(f\'\\) có hai nghiệm phân biệt và đổi dấu tại đó.'),
  [T('\\(f\'(x)=3x^2-6x+m\\) is a quadratic.', '\\(f\'(x)=3x^2-6x+m\\) là tam thức bậc hai.'),
   T('Two distinct roots: \\(\\Delta\'=9-3m>0\\), so \\(m<3\\).', 'Hai nghiệm phân biệt: \\(\\Delta\'=9-3m>0\\) nên \\(m<3\\).')],
  '\\(m<3\\)')
pr2 = [(('A. Multiple Choice', 'A. Trắc nghiệm nhiều lựa chọn'), [
  MCQ(1, ('At which \\(x\\) does \\(f(x)=x^2-4x+1\\) have a local minimum?', 'Hàm số \\(f(x)=x^2-4x+1\\) đạt cực tiểu tại \\(x\\) bằng bao nhiêu?'), ['x=-2', 'x=2', 'x=4', 'x=1'], 'b', ('Answer: b. \\(f\'(x)=2x-4=0\\) at \\(x=2\\) and \\(f\'\'=2>0\\).', 'Đáp án b. \\(f\'(x)=2x-4=0\\) tại \\(x=2\\) và \\(f\'\'=2>0\\).')),
  MCQ(2, ('At which \\(x\\) does \\(f(x)=-x^3+3x\\) have a local maximum?', 'Hàm số \\(f(x)=-x^3+3x\\) đạt cực đại tại \\(x\\) bằng bao nhiêu?'), ['x=-1', 'x=0', 'x=1', 'x=3'], 'c', ('Answer: c. \\(f\'(x)=-3x^2+3=0\\) at \\(x=\\pm1\\), and \\(f\'\'(1)=-6<0\\).', 'Đáp án c. \\(f\'(x)=-3x^2+3=0\\) tại \\(x=\\pm1\\), và \\(f\'\'(1)=-6<0\\).')),
  MCQ(3, ('Let \\(f\'(x)=x(x-1)^2(x+2)\\). How many extreme points does \\(f\\) have?', 'Cho \\(f\'(x)=x(x-1)^2(x+2)\\). Hàm số \\(f\\) có bao nhiêu điểm cực trị?'), ['1', '2', '3', '4'], 'b', ('Answer: b. \\(f\'\\) changes sign at \\(x=0\\) and \\(x=-2\\), but not at \\(x=1\\) because \\((x-1)^2\\ge0\\).', 'Đáp án b. \\(f\'\\) đổi dấu tại \\(x=0\\) và \\(x=-2\\), nhưng không đổi dấu tại \\(x=1\\) vì \\((x-1)^2\\ge0\\).'))]),
 (('B. True or False', 'B. Đúng hoặc sai'), [
  TF(4, ('True or false: if \\(f\'(x_0)=0\\), then \\(x_0\\) is an extreme point.', 'Đúng hay sai: nếu \\(f\'(x_0)=0\\) thì \\(x_0\\) là điểm cực trị.'), 'false', ('False. For \\(f(x)=x^3\\), \\(f\'(0)=0\\) but there is no extremum.', 'Sai. Với \\(f(x)=x^3\\), \\(f\'(0)=0\\) nhưng không có cực trị.')),
  TF(5, ('True or false: \\(f(x)=|x|\\) has a local minimum at \\(x=0\\), although \\(f\'(0)\\) does not exist.', 'Đúng hay sai: \\(f(x)=|x|\\) đạt cực tiểu tại \\(x=0\\) dù không tồn tại \\(f\'(0)\\).'), 'true', ('True. \\(f(x)\\ge0=f(0)\\) near 0, and \\(f\'\\) changes from \\(-1\\) to \\(1\\).', 'Đúng. \\(f(x)\\ge0=f(0)\\) gần 0, và \\(f\'\\) đổi từ \\(-1\\) sang \\(1\\).')),
  TF(6, ('True or false: \\(f(x)=x^4\\) has a local minimum at \\(x=0\\) even though \\(f\'\'(0)=0\\).', 'Đúng hay sai: \\(f(x)=x^4\\) đạt cực tiểu tại \\(x=0\\) dù \\(f\'\'(0)=0\\).'), 'true', ('True. \\(f\'(x)=4x^3\\) changes from negative to positive at 0. The second derivative test simply fails here.', 'Đúng. \\(f\'(x)=4x^3\\) đổi dấu từ âm sang dương tại 0. Điều kiện đủ thứ hai không kết luận được ở đây.'))]),
 (('C. Short Answer', 'C. Trả lời ngắn'), [
  SHORT(7, ('Find the local minimum value of \\(f(x)=x^3-3x\\).', 'Tìm giá trị cực tiểu của hàm số \\(f(x)=x^3-3x\\).'), '-2', 'number', ('Enter a number.', 'Nhập một số.'), ('Answer: \\(-2\\). The local minimum is at \\(x=1\\): \\(f(1)=1-3=-2\\).', 'Đáp án: \\(-2\\). Cực tiểu tại \\(x=1\\): \\(f(1)=1-3=-2\\).')),
  SHORT(8, ('How many extreme points does \\(f(x)=x^4-2x^2\\) have?', 'Hàm số \\(f(x)=x^4-2x^2\\) có bao nhiêu điểm cực trị?'), '3', 'number', ('Enter a whole number.', 'Nhập một số nguyên.'), ('Answer: 3 (two minima and one maximum).', 'Đáp án: 3 (hai cực tiểu và một cực đại).')),
  SHORT(9, ('Find the largest integer \\(m\\) such that \\(f(x)=x^3-3x^2+mx\\) has two extreme points.', 'Tìm số nguyên \\(m\\) lớn nhất để \\(f(x)=x^3-3x^2+mx\\) có hai điểm cực trị.'), '2', 'number', ('Enter a whole number.', 'Nhập một số nguyên.'), ('Answer: 2. We need \\(m<3\\).', 'Đáp án: 2. Cần \\(m<3\\).')),
  SHORT(10, ('Find the local minimum value of \\(f(x)=x+\\dfrac4x\\) for \\(x>0\\).', 'Tìm giá trị cực tiểu của \\(f(x)=x+\\dfrac4x\\) với \\(x>0\\).'), '4', 'number', ('Enter a number.', 'Nhập một số.'), ('Answer: 4. \\(f\'(x)=1-\\dfrac4{x^2}=0\\) at \\(x=2\\), \\(f\'\'(2)=1>0\\), and \\(f(2)=2+2=4\\).', 'Đáp án: 4. \\(f\'(x)=1-\\dfrac4{x^2}=0\\) tại \\(x=2\\), \\(f\'\'(2)=1>0\\) và \\(f(2)=2+2=4\\).'))])]
build('g12-mono-02', 'Local Extrema', 'Cực trị của hàm số', CAT,
  {'level': ('Intermediate', 'Trung bình'), 'time': ('about 45 minutes', 'khoảng 45 phút'), 'before': ('monotonicity of functions, second derivative', 'tính đơn điệu của hàm số, đạo hàm cấp hai')},
  [('define a local maximum and a local minimum;', 'định nghĩa điểm [[cực đại]] và điểm [[cực tiểu]];'), ('find extrema with the first and second derivative tests;', 'tìm [[cực trị]] bằng hai điều kiện đủ;'),
   ('explain why \\(f\'(x_0)=0\\) is not enough;', 'giải thích vì sao \\(f\'(x_0)=0\\) chưa đủ;'), ('say the results in English.', 'phát biểu kết quả bằng tiếng Anh.')],
  [('<b>extremum</b> (plural: extrema) – a local maximum or a local minimum.', '[[Cực trị]] – điểm cực đại hoặc cực tiểu.'), ('<b>local maximum</b> – a point where \\(f\\) is larger than at nearby points.', '[[Cực đại]] – điểm mà \\(f\\) lớn hơn ở các điểm lân cận.'),
   ('<b>local minimum</b> – a point where \\(f\\) is smaller than at nearby points.', '[[Cực tiểu]] – điểm mà \\(f\\) nhỏ hơn ở các điểm lân cận.'), ('<b>critical point</b> – a point where \\(f\'=0\\) or \\(f\'\\) does not exist.', '[[Điểm tới hạn]] – điểm mà \\(f\'=0\\) hoặc \\(f\'\\) không xác định.'),
   ('<b>second derivative</b> – the derivative of the derivative, \\(f\'\'\\).', '[[Đạo hàm cấp hai]] – đạo hàm của đạo hàm, \\(f\'\'\\).'), ('<b>variation table</b> – a table of the sign of \\(f\'\\) and the behavior of \\(f\\).', '[[Bảng biến thiên]] – bảng ghi dấu \\(f\'\\) và chiều biến thiên của \\(f\\).')],
  [('Find the local extrema of the function.', 'Tìm các cực trị của hàm số.'), ('The function has a local maximum at \\(x=0\\).', 'Hàm số đạt cực đại tại \\(x=0\\).'), ('Use the second derivative test.', 'Dùng điều kiện đủ thứ hai (đạo hàm cấp hai).'), ('The derivative changes sign at this point.', 'Đạo hàm đổi dấu tại điểm này.')],
  review2, theory2, ex2, pr2,
  [('<b>Treating every root of \\(f\'\\) as an extremum.</b> The sign of \\(f\'\\) must change.', '<b>Coi mọi nghiệm của \\(f\'\\) là cực trị.</b> Dấu của \\(f\'\\) phải đổi.'),
   ('<b>Mixing the point and the value.</b> The local maximum is at \\(x=0\\); the maximum value is \\(f(0)\\).', '<b>Nhầm điểm cực trị với giá trị cực trị.</b> Cực đại đạt tại \\(x=0\\); giá trị cực đại là \\(f(0)\\).'),
   ('<b>Trusting the second derivative test when \\(f\'\'(x_0)=0\\).</b> Then use the sign of \\(f\'\\).', '<b>Tin điều kiện đủ thứ hai khi \\(f\'\'(x_0)=0\\).</b> Khi đó phải xét dấu \\(f\'\\).')],
  [('A local extremum needs \\(f\'\\) to change sign.', 'Cực trị cần \\(f\'\\) đổi dấu.'), ('\\(f\'\'(x_0)<0\\) gives a maximum; \\(f\'\'(x_0)>0\\) gives a minimum.', '\\(f\'\'(x_0)<0\\) cho cực đại; \\(f\'\'(x_0)>0\\) cho cực tiểu.'), ('\\(f\'(x_0)=0\\) is necessary but not sufficient.', '\\(f\'(x_0)=0\\) là điều kiện cần, chưa đủ.')],
  [('I can find local extrema using the sign of \\(f\'\\).', 'Em tìm được cực trị bằng dấu của \\(f\'\\).'), ('I can use the second derivative test.', 'Em dùng được đạo hàm cấp hai để tìm cực trị.'), ('I can explain why \\(f\'(x_0)=0\\) is not enough.', 'Em giải thích được vì sao \\(f\'(x_0)=0\\) chưa đủ.'), ('I understand the English instructions in this lesson.', 'Em hiểu các yêu cầu bằng tiếng Anh trong bài này.')],
  'lessons/grade12/monotonicity-extrema/local-extrema.html',
  ENTRY('g12-mono-02', 'Local Extrema', 'Find local maxima and minima with the first and second derivative tests.', 'Intermediate', 45, ['g12-mono-01'], 'lessons/grade12/monotonicity-extrema/local-extrema.html', ['extrema', 'local maximum', 'local minimum', 'derivative']))

# =====================================================================
# BÀI 3: Maximum and Minimum Values
# =====================================================================
review3 = T('You can already find the critical points of a function and the sign of \\(f\'\\). A <b>continuous function</b> has no jumps or holes on its interval. Now we compare function values to find the largest and the smallest.', 'Em đã biết tìm điểm tới hạn và xét dấu \\(f\'\\). [[Hàm số liên tục]] không bị đứt đoạn trên khoảng đang xét. Bây giờ ta so sánh các giá trị hàm số để tìm giá trị lớn nhất và nhỏ nhất.')
theory3 = ('<h3>5.1 %s</h3>' % TI('Definitions', 'Định nghĩa') +
  BOX('mint', ('Definition', 'Định nghĩa'), T('The <b>maximum value</b> of \\(f\\) on \\(K\\) is a number \\(M=f(x_0)\\) with \\(x_0\\in K\\) and \\(f(x)\\le M\\) for all \\(x\\in K\\). The <b>minimum value</b> is defined in the same way with \\(f(x)\\ge m\\). We write \\(\\max_K f\\) and \\(\\min_K f\\).',
     '[[Giá trị lớn nhất]] của \\(f\\) trên \\(K\\) là số \\(M=f(x_0)\\) với \\(x_0\\in K\\) và \\(f(x)\\le M\\) với mọi \\(x\\in K\\). [[Giá trị nhỏ nhất]] định nghĩa tương tự với \\(f(x)\\ge m\\). Kí hiệu \\(\\max_K f\\) và \\(\\min_K f\\).')) +
  '<h3>5.2 %s</h3>' % TI('On a closed interval \\([a,b]\\)', 'Trên đoạn \\([a,b]\\)') +
  BOX('mint', ('Theorem', 'Định lí'), T('A continuous function on \\([a,b]\\) always has a maximum value and a minimum value.', 'Hàm số liên tục trên đoạn \\([a,b]\\) luôn có giá trị lớn nhất và giá trị nhỏ nhất.')) +
  OL([T('Find the critical points of \\(f\\) that lie inside \\((a,b)\\).', 'Tìm các [[điểm tới hạn]] của \\(f\\) nằm trong \\((a,b)\\).'), T('Compute \\(f\\) at these points and at the two <b>endpoints</b> \\(a\\) and \\(b\\).', 'Tính \\(f\\) tại các điểm đó và tại hai [[đầu mút]] \\(a\\), \\(b\\).'), T('The largest number is the maximum value; the smallest is the minimum value.', 'Số lớn nhất là giá trị lớn nhất; số nhỏ nhất là giá trị nhỏ nhất.')]) +
  '<h3>5.3 %s</h3>' % TI('On other intervals', 'Trên khoảng khác') +
  T('On \\((a,b)\\), \\((a,+\\infty)\\) and so on, make a variation table and look at the limits at the ends. A maximum or minimum may not exist.', 'Trên \\((a,b)\\), \\((a,+\\infty)\\),… hãy lập [[bảng biến thiên]] và xét giới hạn ở hai đầu. Giá trị lớn nhất hay nhỏ nhất có thể không tồn tại.'))
ex3 = EXAMPLE(1, ('Basic', 'Cơ bản'), ('A closed interval', 'Trên một đoạn'),
  T('Find the maximum and minimum values of \\(f(x)=x^3-3x+1\\) on \\([0,2]\\).', 'Tìm giá trị lớn nhất và nhỏ nhất của \\(f(x)=x^3-3x+1\\) trên đoạn \\([0,2]\\).'),
  ('Use the three-step method on a closed interval.', 'Dùng phương pháp ba bước trên một đoạn.'),
  [T('\\(f\'(x)=3x^2-3=0\\) gives \\(x=\\pm1\\). Only \\(x=1\\) is in \\((0,2)\\).', '\\(f\'(x)=3x^2-3=0\\) cho \\(x=\\pm1\\). Chỉ \\(x=1\\) thuộc \\((0,2)\\).'),
   T('\\(f(0)=1\\), \\(f(1)=-1\\), \\(f(2)=3\\).', '\\(f(0)=1\\), \\(f(1)=-1\\), \\(f(2)=3\\).'), T('The maximum value is \\(3\\) (at \\(x=2\\)); the minimum value is \\(-1\\) (at \\(x=1\\)).', 'Giá trị lớn nhất là \\(3\\) (tại \\(x=2\\)); giá trị nhỏ nhất là \\(-1\\) (tại \\(x=1\\)).')],
  '\\(\\max=3\\), \\(\\min=-1\\)')
ex3 += EXAMPLE(2, ('Intermediate', 'Trung bình'), ('Two critical points inside', 'Hai điểm tới hạn nằm trong đoạn'),
  T('Find the maximum and minimum values of \\(f(x)=2x^3+3x^2-12x\\) on \\([-3,2]\\).', 'Tìm giá trị lớn nhất và nhỏ nhất của \\(f(x)=2x^3+3x^2-12x\\) trên đoạn \\([-3,2]\\).'),
  ('Factor \\(f\'\\) and check both roots.', 'Phân tích \\(f\'\\) và xét cả hai nghiệm.'),
  [T('\\(f\'(x)=6x^2+6x-12=6(x+2)(x-1)\\). Both \\(x=-2\\) and \\(x=1\\) are in \\((-3,2)\\).', '\\(f\'(x)=6x^2+6x-12=6(x+2)(x-1)\\). Cả \\(x=-2\\) và \\(x=1\\) đều thuộc \\((-3,2)\\).'),
   T('\\(f(-3)=9\\), \\(f(-2)=20\\), \\(f(1)=-7\\), \\(f(2)=4\\).', '\\(f(-3)=9\\), \\(f(-2)=20\\), \\(f(1)=-7\\), \\(f(2)=4\\).'), T('So the maximum value is \\(20\\) and the minimum value is \\(-7\\).', 'Vậy giá trị lớn nhất là \\(20\\) và giá trị nhỏ nhất là \\(-7\\).')],
  '\\(\\max=20\\), \\(\\min=-7\\)')
ex3 += EXAMPLE(3, ('Intermediate', 'Trung bình'), ('An interval that is not closed', 'Khoảng không phải đoạn'),
  T('Find the minimum value of \\(f(x)=x+\\dfrac4x\\) on \\((0,+\\infty)\\). Does a maximum value exist?', 'Tìm giá trị nhỏ nhất của \\(f(x)=x+\\dfrac4x\\) trên \\((0,+\\infty)\\). Có giá trị lớn nhất không?'),
  ('There are no endpoints in the interval, so use a variation table.', 'Khoảng này không chứa đầu mút nên dùng bảng biến thiên.'),
  [T('\\(f\'(x)=1-\\dfrac4{x^2}=0\\) gives \\(x=2\\). \\(f\'<0\\) on \\((0,2)\\) and \\(f\'>0\\) on \\((2,+\\infty)\\).', '\\(f\'(x)=1-\\dfrac4{x^2}=0\\) cho \\(x=2\\). \\(f\'<0\\) trên \\((0,2)\\) và \\(f\'>0\\) trên \\((2,+\\infty)\\).'),
   T('So the minimum value is \\(f(2)=4\\).', 'Vậy giá trị nhỏ nhất là \\(f(2)=4\\).'), T('As \\(x\\to0^+\\) or \\(x\\to+\\infty\\), \\(f(x)\\to+\\infty\\), so there is no maximum value.', 'Khi \\(x\\to0^+\\) hoặc \\(x\\to+\\infty\\) thì \\(f(x)\\to+\\infty\\), nên không có giá trị lớn nhất.')],
  '\\(\\min=4\\); no maximum value')
ex3 += EXAMPLE(4, ('Advanced', 'Nâng cao'), ('An application', 'Bài toán thực tế'),
  T('A rectangle has perimeter 20 cm. Find its largest possible area.', 'Một hình chữ nhật có chu vi 20 cm. Tìm diện tích lớn nhất có thể.'),
  ('Write the area as a function of one side.', 'Viết diện tích như hàm số của một cạnh.'),
  [T('Let one side be \\(x\\) cm, so the other is \\(10-x\\), with \\(0<x<10\\). The area is \\(S(x)=x(10-x)=10x-x^2\\).', 'Gọi một cạnh là \\(x\\) cm thì cạnh kia là \\(10-x\\), với \\(0<x<10\\). Diện tích \\(S(x)=x(10-x)=10x-x^2\\).'),
   T('\\(S\'(x)=10-2x=0\\) gives \\(x=5\\). \\(S\'>0\\) for \\(x<5\\) and \\(S\'<0\\) for \\(x>5\\).', '\\(S\'(x)=10-2x=0\\) cho \\(x=5\\). \\(S\'>0\\) khi \\(x<5\\) và \\(S\'<0\\) khi \\(x>5\\).'),
   T('The maximum is \\(S(5)=25\\): the best rectangle is a square.', 'Giá trị lớn nhất là \\(S(5)=25\\): hình chữ nhật tốt nhất là hình vuông.')],
  '\\(25\\ \\text{cm}^2\\)')
pr3 = [(('A. Multiple Choice', 'A. Trắc nghiệm nhiều lựa chọn'), [
  MCQ(1, ('What is the maximum value of \\(f(x)=-x^2+2x+3\\) on \\(\\mathbb{R}\\)?', 'Giá trị lớn nhất của \\(f(x)=-x^2+2x+3\\) trên \\(\\mathbb{R}\\) là bao nhiêu?'), ['3', '4', '5', '2'], 'b', ('Answer: b. The vertex is at \\(x=1\\), and \\(f(1)=4\\).', 'Đáp án b. Đỉnh tại \\(x=1\\), và \\(f(1)=4\\).')),
  MCQ(2, ('What is the minimum value of \\(f(x)=x^2-2x\\) on \\([0,3]\\)?', 'Giá trị nhỏ nhất của \\(f(x)=x^2-2x\\) trên \\([0,3]\\) là bao nhiêu?'), ['-1', '0', '3', '-2'], 'a', ('Answer: a. \\(f(0)=0\\), \\(f(1)=-1\\), \\(f(3)=3\\).', 'Đáp án a. \\(f(0)=0\\), \\(f(1)=-1\\), \\(f(3)=3\\).')),
  MCQ(3, ('What is the minimum value of \\(f(x)=4-x^2\\) on \\([-1,3]\\)?', 'Giá trị nhỏ nhất của \\(f(x)=4-x^2\\) trên \\([-1,3]\\) là bao nhiêu?'), ['-5', '3', '4', '-1'], 'a', ('Answer: a. \\(f(-1)=3\\), \\(f(0)=4\\), \\(f(3)=-5\\).', 'Đáp án a. \\(f(-1)=3\\), \\(f(0)=4\\), \\(f(3)=-5\\).'))]),
 (('B. True or False', 'B. Đúng hoặc sai'), [
  TF(4, ('True or false: a continuous function on a closed interval \\([a,b]\\) always has a maximum value and a minimum value.', 'Đúng hay sai: hàm số liên tục trên đoạn \\([a,b]\\) luôn có giá trị lớn nhất và giá trị nhỏ nhất.'), 'true', ('True. This is the extreme value theorem.', 'Đúng. Đây là định lí về giá trị lớn nhất, nhỏ nhất của hàm liên tục trên đoạn.')),
  TF(5, ('True or false: \\(f(x)=\\dfrac1x\\) has a maximum value on \\((0,1]\\).', 'Đúng hay sai: \\(f(x)=\\dfrac1x\\) có giá trị lớn nhất trên \\((0,1]\\).'), 'false', ('False. \\(f(x)\\to+\\infty\\) as \\(x\\to0^+\\). The minimum value is \\(f(1)=1\\).', 'Sai. \\(f(x)\\to+\\infty\\) khi \\(x\\to0^+\\). Giá trị nhỏ nhất là \\(f(1)=1\\).'))]),
 (('C. Short Answer', 'C. Trả lời ngắn'), [
  SHORT(6, ('Find the maximum value of \\(f(x)=x^3-3x\\) on \\([0,2]\\).', 'Tìm giá trị lớn nhất của \\(f(x)=x^3-3x\\) trên đoạn \\([0,2]\\).'), '2', 'number', ('Enter a number.', 'Nhập một số.'), ('Answer: 2. \\(f(0)=0\\), \\(f(1)=-2\\), \\(f(2)=2\\).', 'Đáp án: 2. \\(f(0)=0\\), \\(f(1)=-2\\), \\(f(2)=2\\).')),
  SHORT(7, ('Find the minimum value of \\(f(x)=x^3-3x\\) on \\([0,2]\\).', 'Tìm giá trị nhỏ nhất của \\(f(x)=x^3-3x\\) trên đoạn \\([0,2]\\).'), '-2', 'number', ('Enter a number.', 'Nhập một số.'), ('Answer: \\(-2\\), reached at \\(x=1\\).', 'Đáp án: \\(-2\\), đạt tại \\(x=1\\).')),
  SHORT(8, ('Find the minimum value of \\(f(x)=x+\\dfrac9x\\) on \\((0,+\\infty)\\).', 'Tìm giá trị nhỏ nhất của \\(f(x)=x+\\dfrac9x\\) trên \\((0,+\\infty)\\).'), '6', 'number', ('Enter a number.', 'Nhập một số.'), ('Answer: 6. \\(f\'(x)=1-\\dfrac9{x^2}=0\\) at \\(x=3\\), and \\(f(3)=3+3=6\\).', 'Đáp án: 6. \\(f\'(x)=1-\\dfrac9{x^2}=0\\) tại \\(x=3\\) và \\(f(3)=3+3=6\\).')),
  SHORT(9, ('Find the maximum value of \\(f(x)=x^4-2x^2\\) on \\([0,2]\\).', 'Tìm giá trị lớn nhất của \\(f(x)=x^4-2x^2\\) trên đoạn \\([0,2]\\).'), '8', 'number', ('Enter a number.', 'Nhập một số.'), ('Answer: 8. \\(f(0)=0\\), \\(f(1)=-1\\), \\(f(2)=8\\).', 'Đáp án: 8. \\(f(0)=0\\), \\(f(1)=-1\\), \\(f(2)=8\\).')),
  SHORT(10, ('A rectangle has perimeter 20 cm. What is the largest possible area, in \\(\\text{cm}^2\\)?', 'Một hình chữ nhật có chu vi 20 cm. Diện tích lớn nhất là bao nhiêu \\(\\text{cm}^2\\)?'), '25', 'number', ('Enter a number.', 'Nhập một số.'), ('Answer: 25 (a square with side 5 cm).', 'Đáp án: 25 (hình vuông cạnh 5 cm).'))])]
build('g12-mono-03', 'Maximum and Minimum Values', 'Giá trị lớn nhất và giá trị nhỏ nhất', CAT,
  {'level': ('Intermediate', 'Trung bình'), 'time': ('about 50 minutes', 'khoảng 50 phút'), 'before': ('critical points, local extrema, variation tables', 'điểm tới hạn, cực trị, bảng biến thiên')},
  [('find the maximum and minimum values on a closed interval;', 'tìm [[giá trị lớn nhất]] và [[giá trị nhỏ nhất]] trên một đoạn;'), ('use a variation table on other intervals;', 'dùng [[bảng biến thiên]] trên các khoảng khác;'), ('solve a simple optimization problem;', 'giải bài toán tối ưu đơn giản;'), ('explain your steps in English.', 'trình bày các bước bằng tiếng Anh.')],
  [('<b>maximum value</b> – the largest value of a function on an interval.', '[[Giá trị lớn nhất]] – giá trị lớn nhất của hàm số trên một khoảng.'), ('<b>minimum value</b> – the smallest value of a function on an interval.', '[[Giá trị nhỏ nhất]] – giá trị nhỏ nhất của hàm số trên một khoảng.'),
   ('<b>endpoint</b> – the first or last point of an interval.', '[[Đầu mút]] – điểm đầu hoặc điểm cuối của một khoảng.'), ('<b>continuous function</b> – a function whose graph has no breaks.', '[[Hàm số liên tục]] – hàm số có đồ thị không bị đứt.'),
   ('<b>critical point</b> – a point where \\(f\'=0\\) or \\(f\'\\) does not exist.', '[[Điểm tới hạn]] – điểm mà \\(f\'=0\\) hoặc \\(f\'\\) không xác định.'), ('<b>variation table</b> – a table showing how \\(f\\) increases and decreases.', '[[Bảng biến thiên]] – bảng cho biết \\(f\\) tăng giảm thế nào.')],
  [('Find the maximum and minimum values of \\(f\\) on the interval \\([0,2]\\).', 'Tìm giá trị lớn nhất và nhỏ nhất của \\(f\\) trên đoạn \\([0,2]\\).'), ('Evaluate the function at the endpoints.', 'Tính giá trị hàm số tại các đầu mút.'), ('The maximum value is reached at \\(x=2\\).', 'Giá trị lớn nhất đạt tại \\(x=2\\).'), ('Does the function have a minimum value? Explain.', 'Hàm số có giá trị nhỏ nhất không? Hãy giải thích.')],
  review3, theory3, ex3, pr3,
  [('<b>Forgetting the endpoints.</b> On \\([a,b]\\) the maximum or minimum is often at \\(a\\) or \\(b\\).', '<b>Quên các đầu mút.</b> Trên \\([a,b]\\), giá trị lớn nhất hay nhỏ nhất thường đạt tại \\(a\\) hoặc \\(b\\).'),
   ('<b>Using a critical point outside the interval.</b> Only points inside \\((a,b)\\) count.', '<b>Dùng điểm tới hạn ngoài đoạn.</b> Chỉ các điểm thuộc \\((a,b)\\) mới được xét.'),
   ('<b>Assuming a maximum always exists.</b> On an interval that is not closed, check the limits.', '<b>Cho rằng luôn có giá trị lớn nhất.</b> Trên khoảng không phải đoạn, phải xét giới hạn.')],
  [('On \\([a,b]\\): compare \\(f\\) at the critical points inside and at \\(a\\), \\(b\\).', 'Trên \\([a,b]\\): so sánh \\(f\\) tại các điểm tới hạn trong khoảng và tại \\(a\\), \\(b\\).'), ('On other intervals: use a variation table and limits.', 'Trên khoảng khác: dùng bảng biến thiên và giới hạn.'), ('For word problems: write one function of one variable, with its domain.', 'Bài toán thực tế: lập một hàm số một biến, kèm tập xác định.')],
  [('I can find max and min values on a closed interval.', 'Em tìm được giá trị lớn nhất, nhỏ nhất trên một đoạn.'), ('I can decide when a maximum or minimum does not exist.', 'Em biết khi nào không tồn tại giá trị lớn nhất hay nhỏ nhất.'), ('I can solve a simple optimization problem.', 'Em giải được bài toán tối ưu đơn giản.'), ('I understand the English instructions in this lesson.', 'Em hiểu các yêu cầu bằng tiếng Anh trong bài này.')],
  'lessons/grade12/monotonicity-extrema/maximum-and-minimum-values.html',
  ENTRY('g12-mono-03', 'Maximum and Minimum Values', 'Find the greatest and smallest values of a function on an interval.', 'Intermediate', 50, ['g12-mono-02'], 'lessons/grade12/monotonicity-extrema/maximum-and-minimum-values.html', ['maximum', 'minimum', 'optimization', 'closed interval']))
