# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mb_extra import *
reorder(10, ['g10-sets-01', 'g10-sets-02', 'g10-algebra-01'])
d = json.load(open(os.path.join(ROOT, 'lessons.json'), encoding='utf-8'))
print([(x['id'], x['grade']) for x in d])
